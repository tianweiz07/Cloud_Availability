
int blk_getimagesize(int fd, uint64_t *size);
int blk_getsectorsize(int fd, uint64_t *sector_size);
