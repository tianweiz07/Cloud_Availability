extern int blk_nb;
extern struct blkfront_dev **blk_dev;
extern struct netfront_dev *net_dev;
extern struct kbdfront_dev *kbd_dev;
extern struct fbfront_dev *fb_dev;
